python3 get_config.py && python3 bot.py
