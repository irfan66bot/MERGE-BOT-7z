#
# (c) Yash Oswal | yashoswal18@gmail.com

from pyrogram import Client
from pyrogram.types import Message
from bot import mergeApp, LOGGER
from config import Config

async def metaEditor(c:Client, m: Message):
    1
